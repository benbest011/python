package cn.richinfo.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.richinfo.util.AesUtil;
import cn.richinfo.util.CommonUtil;
import cn.richinfo.util.HttpClientUtil;
import cn.richinfo.util.PropertiesUtils;
import cn.richinfo.util.ResponseUtil;

/**
 * 智能链接自动取号
 */
@Controller
@RequestMapping("/sn")
public class SnController {
	private static Logger log = Logger.getLogger(SnController.class);
	
	//智能链接AccessToken接口
	private final static String INTERFACE_SN_AT = PropertiesUtils.getProperties("INTERFACE_SN_AT");
	
	//智能链接获取手机号接口
	private final static String INTERFACE_SN_PHONE = PropertiesUtils.getProperties("INTERFACE_SN_PHONE");
	
	//智能链接获取带参拼接后的URL
	private final static String INTERFACE_SN_URL = PropertiesUtils.getProperties("INTERFACE_SN_URL");
	
	/**
	 * 获取智能链接token
	 * @param response
	 * @return json
	 */
	@RequestMapping(value="/getAccessToken", method = RequestMethod.POST)
	public void getAccessToken(HttpServletResponse response) {
		String json = null ;
		try {
			json =  HttpClientUtil.httpGetRequest(INTERFACE_SN_AT);
			log.info("智能链接获取token返回Json:"+ json);
		} catch (Exception e) {
			log.error("获取智能链接token异常");
			e.printStackTrace();
		}
		ResponseUtil.printResult(response, JSON.toJSONString(json));
	}
	
	/**
	 * 智能链接获取手机号
	 * @param request
	 * @param response
	 * @return 手机号
	 */
	@RequestMapping(value="/getMobliePhone", method=RequestMethod.POST)
	public void getMobliePhone(HttpServletRequest request,
			HttpServletResponse response
			){
		Map<String,Object> data = new HashMap<String, Object>();
		String message = request.getParameter("message");
		
		String phone = null ;
		String aesPhone = null;
		try {
			phone =  HttpClientUtil.httpGetRequest(INTERFACE_SN_PHONE+"?message="+message);
			log.info("智能链接获取手机号:"+phone);
			//加密手机号，用于前后端页面传值对比判断是否智能链接号码
			aesPhone = AesUtil.encrypt(phone, "hfxisgod09271142");
		} catch (Exception e) {
			log.error("智能链接获取手机号异常");
			e.printStackTrace();
		}
		
		data.put("mobilePhone", CommonUtil.filterPhoneString(phone));//加星号前端显示
		data.put("aesPhone", aesPhone);
		
		//设置session
		request.getSession().setAttribute("snPhone", phone);
		request.getSession().setAttribute("aesPhone", aesPhone);
		
		ResponseUtil.printResult(response, JSON.toJSONString(data));
	}

	/**
	 * 获取智能链接带参拼接后的URL
	 * @param response
	 * @return json
	 * @author chuanye
	 */
	@RequestMapping(value="/snurl/", method = RequestMethod.POST)
	public void getSnUlr(HttpServletResponse response) {
		String snUrl = null ;
		try {
			snUrl = HttpClientUtil.httpGetRequest(INTERFACE_SN_URL);
			//logger.info("智能链接获取带参拼接后的URL返回JSON:"+ snUrl +", 接口："+INTERFACE_SN_URL);
		} catch (Exception e) {
			log.error("获取智能链接带参拼接后的URL异常");
			e.printStackTrace();
		}
		ResponseUtil.printResult(response, snUrl);
	}
	
	
	/**
	 * 登出 清空所有session
	 * @param request
	 * @author chuanye
	 */
	@RequestMapping(value="/loginOut/")
	@ResponseBody
	public String loginOut(HttpServletRequest request, HttpServletResponse response){
		//request.getSession().invalidate();	//注销所有session 会影响用户session
		request.getSession().setAttribute("snPhone", null);
		request.getSession().setAttribute("aesPhone", null);
		request.getSession().setAttribute("phone", null);
		return "";
	}
	
	/**
	 * 智能链接安全判断
	 * @param aesPhone 智能链接获取的号码-加密后
	 * @param phone 智能链接获取的号码
	 * @return
	 */
	public Boolean checkSnReq(String aesPhone, String phone) {
		String keySign = AesUtil.encrypt(phone, "hfxisgod09271142");
		if (!keySign.equals(aesPhone)) {
			return false;
		}
		return true;
	}
	
	public static void main(String[] args) {
		String aesPhone = AesUtil.encrypt("15814850826", "hfxisgod09271142");
		System.out.println(aesPhone);//oU7C0zfjPXuNy5eycljdfA==
		
		
		System.out.println(CommonUtil.filterPhoneString("15814850826"));
		
	}
}
