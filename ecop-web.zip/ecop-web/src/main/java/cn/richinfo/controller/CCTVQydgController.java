package cn.richinfo.controller;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cn.richinfo.domain.QydgOrder;
import cn.richinfo.service.MobilPhoneService;
import cn.richinfo.service.QydgService;
import cn.richinfo.service.SmsService;
import cn.richinfo.util.AesUtil;
import cn.richinfo.util.DateUtil;
import cn.richinfo.util.RandomUtil;
import cn.richinfo.util.RequestUtil;
import cn.richinfo.util.ResponseUtil;
import cn.richinfo.util.StringUtil;
import cn.richinfo.web.util.PropertiesUtils;

/**
 * 权益订购控制层
 * @author chuanye
 *
 */
@Controller
@RequestMapping("/cctv")
public class CCTVQydgController {
	
	private static Logger log = Logger.getLogger(CCTVQydgController.class);
	
	//调试模式
	private static final String DEBUG = PropertiesUtils.getProperties("DEBUG");
	
	@Autowired
	MobilPhoneService mobilPhoneService;
	
	@Autowired
	SmsService smsService;
	
	@Autowired
	QydgService qydgService;
	
	/**
	 * cctv权益订购首页
	 * @return
	 */
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView cctvIndex(HttpServletRequest request,
			@RequestParam(value="sspId" ,required=false ,defaultValue="") String sspId,
			ModelMap modelMap){
		modelMap.addAttribute("sspId", sspId);//渠道来源标识
		//设置session
		request.getSession().setAttribute("submit", RandomUtil.getNumBylen(16));
		return new ModelAndView("cctv/index");
	}
	
	/**
	 * cctv权益订购 保存
	 * @return
	 */
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public void cctvSave(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="phone" ,required=true ,defaultValue="") String phone,
			@RequestParam(value="sspId" ,required=false ,defaultValue="") String sspId,
			@RequestParam(value="proid" ,required=true ,defaultValue="") String proid,
			@RequestParam(value="yzm" ,required=false ,defaultValue="") String yzm,
			@RequestParam(value="aesPhone" ,required=false ,defaultValue="") String aesPhone,
			ModelMap modelMap){
		
		log.debug("DEBUG模式："+ DEBUG);
		
//		String submit = (String)request.getSession().getAttribute("submit");
//		if(StringUtil.isBlank(submit)) {
//			ResponseUtil.printResult(response, 501, "页面过期！请重新刷新本页面");
//			return ;
//		}
		
		//如果aesPhone有值 表示智能链接取号
		if(StringUtil.isNotBlank(aesPhone)) {
			//解密号码
			try {
				phone = AesUtil.decrypt(aesPhone, "hfxisgod09271142");
				log.info("解密号码"+phone);
			} catch (Exception e) {
				ResponseUtil.printResult(response, 502, "请输入正确的广东移动手机号");
				return ;
			}
			
		}else if(!"true".equals(DEBUG)){//调式模式
			 //校验验证码
			if(!this.checkSms(yzm, request)) {
				ResponseUtil.printResult(response, 501, "请输入正确的验证码");
				return ;
			}
		}
		
		//判断是否广东移动用户
		if(!mobilPhoneService.checkPhoneArea(phone,"1")) {
			ResponseUtil.printResult(response, 502, "请输入正确的广东移动手机号");
			return ;
		}
		
		//判断是否重复下单
		if(this.qydgService.count7day(phone, "cctv")) {
			ResponseUtil.printResult(response, 503, "有效期内不可重复订购");
			return ;
		}
		
		String subject = "";
		String orderStatus = ""; //订单状态
		Double price = 0.00D;
		String productid = null; //产品编码
		switch (proid) {
		case "699":
			price = 6.99D;
			subject = "省内通用流量1GB有效期7天-央视视频会员7天";
			productid = "YS1G7";
			break;
			
		case "1699":
			price = 16.99D;
			subject = "省内通用流量10GB有效期7天-央视视频会员7天";
			productid = "YS20G7";
			break;

		default:
			ResponseUtil.printResult(response, 504, "拒绝提交");
			return ;
		}
		
		//订购流量
		if("true".equals(DEBUG)){
			orderStatus = "0";
		}else {
			orderStatus = this.mobilPhoneService.ECOP_SERVICE_0009(phone, "caixuncctv", "caixuncctv", productid);
		}
		
		/* 保存订单信息 */
		QydgOrder qydgOrder = new QydgOrder();
		qydgOrder.setOrderNumber(RandomUtil.getNumBylen(20)); //订单号
		qydgOrder.setPhone(phone);
		qydgOrder.setProductName(subject);
		qydgOrder.setOrderStatus(orderStatus);
		qydgOrder.setPrice(price);
		qydgOrder.setSspId(sspId);
		qydgOrder.setIp(RequestUtil.getUserIp(request));
		qydgOrder.setAddTime(new Date());
		qydgOrder.setBusinessType("cctv");
		
		log.debug(qydgOrder);
		try {
			qydgService.saveQydgOrder(qydgOrder);
		} catch (Exception e) {
			log.error("订购数据入库异常");
			e.printStackTrace();
		}
		/* 保存订单信息 end */
		
		ResponseUtil.printResult(response, 200, orderStatus);
	}
	
	
	
	/**
	 * 发送短信验证码
	 * @param request
	 * @param response
	 * @param phone
	 */
	@RequestMapping(value="/sendSms",method=RequestMethod.POST)
	public void sendSms(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="phone",required=true) String phone,
			Map<String, String> map
			){
		
//		String submit = (String)request.getSession().getAttribute("submit");
//		if(StringUtil.isBlank(submit)) {
//			ResponseUtil.printResult(response, 500, "页面过期！请重新刷新本页面");
//			return ;
//		}
		
		//判断是否广东移动用户
		if(!mobilPhoneService.checkPhoneArea(phone,"1")) {
			ResponseUtil.printResult(response, 501, "请输入正确的广东移动手机号");
			return ;
		}
		
		//判断是否重复下单
		if(this.qydgService.count7day(phone, "cctv")) {
			ResponseUtil.printResult(response, 502, "有效期内不可重复订购");
			return ;
		}
		
		//调式模式
		if("true".equals(DEBUG)) {
			ResponseUtil.printResult(response, 200, "验证码发送成功");
			return ;
		}
		
		//发送验证码
		String smsCode = (String)request.getSession().getAttribute("smsCode");
		if(StringUtil.isBlank(smsCode)) {
			smsCode = RandomUtil.getNumBylen(6);
			request.getSession().setAttribute("smsCode", smsCode);
		}
		request.getSession().setAttribute("sendTime", new Date());
		
        String content = "【验证码】尊敬的订购用户：您本次的短信验证码："+smsCode+"，请您在5分钟内填写，安全提醒，请勿将验证码提供给他人。";
		if(this.smsService.sendSmsContent(phone, content)) {
			ResponseUtil.printResult(response, 200, "验证码发送成功");
		}else {
			ResponseUtil.printResult(response, 500, "验证码发送失败");
		}
	}
	
	/**
	 * 核验验证码
	 * @param yzm
	 * @param request
	 * @return
	 */
	public boolean checkSms(String yzm, HttpServletRequest request) {
		//取session验证码
		String smsCode = (String)request.getSession().getAttribute("smsCode");
		Date sendTime = (Date)request.getSession().getAttribute("sendTime");
		if(smsCode == null || sendTime == null) {
			return false;
		}
		//是否超时 5分钟
		if(DateUtil.DateDiff(null, sendTime, "M") <= 5) {
			//核验验证码
			if(smsCode != null && smsCode.equals(yzm)) {
				request.getSession().setAttribute("smsCode", null);
				request.getSession().setAttribute("sendTime", null);
				return true;
			}
		}
		return false;
	}
	
}
