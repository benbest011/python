package cn.richinfo.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.richinfo.service.SmsService;
import cn.richinfo.util.ResponseUtil;
import cn.richinfo.util.StringUtil;
import cn.richinfo.web.util.PropertiesUtils;

/**
 * 短信验证码
 *
 */
@Controller
@RequestMapping("/sms/")
public class SmsController {
	
	private static Logger logger = Logger.getLogger(SmsController.class);
	
	private static final String DEBUG = PropertiesUtils.getProperties("DEBUG");
	
	@Resource
	SmsService smsService ;
	
	/**
	 * 发送验证码
	 * @return json
	 */
	@RequestMapping(value="sendSMS/")
	public void sendSMS(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="phone", required=true) String phone
			) {
		String resCode = null;
		resCode = smsService.sendSMS(phone);
		logger.info("发送验证码-返回resCode:"+ resCode);
		ResponseUtil.printResult(response, resCode);
	}
	
	/**
	 * 验证短信验证码
	 * @return json 
	 */
	@RequestMapping(value="checkSMS/")
	public void checkSMS(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="phone", required=true) String phone,
			@RequestParam(value="code", required=true) String smsCode
			) {
		String resCode = null;
		if("true".equals(DEBUG)){
			resCode = "0" ;
		}else{
			resCode = smsService.checkSMS(phone, smsCode, request);
		}
		logger.info("发送验证码-返回resCode:"+ resCode);
		ResponseUtil.printResult(response, resCode);
	}
	
	
	/**
	 * 发送短信
	 * @return json 
	 */
	@RequestMapping(value="sendSMSContent/")
	public void sendSMSContent(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="phone", required=true) String phone
			) {
		if(StringUtil.isNotBlank(phone) && phone.length() == 11) {
			String content = "尊敬的客户：您已成功订购业务并获得300分钟和飞信免费通话时长奖励，登录和飞信APP-“我”-“多方电话”即可查询使用免费时长！戳我立即体验：http://feixin.10086.cn【中国移动】";
			this.smsService.sendSmsContent(phone, content);
		}
	}
	
	
}
