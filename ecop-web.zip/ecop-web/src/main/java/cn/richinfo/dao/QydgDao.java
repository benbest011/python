package cn.richinfo.dao;

import cn.richinfo.domain.QydgOrder;
/**
 * 权益订购订单dao
 * @author chuanye
 *
 */
public interface QydgDao {
	/**
	 * 保存订单信息
	 * @return
	 */
	Integer saveQydgOrder(QydgOrder qydgOrder);
	
	/**
	 * 根据手机查询用户7天是否已购买过，有记录表示已购买过 
	 * @param QydgOrder
	 * @return
	 */
	Long count7day(QydgOrder qydgOrder);
	
}
