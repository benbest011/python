package cn.richinfo.domain;

import java.io.Serializable;
import java.util.Date;
/**
 * 权益订购订单实体类
 * @author chuanye
 *
 */
public class QydgOrder implements Serializable{

	private static final long serialVersionUID = 6547011866250942104L;
	
	private Integer id ; //主键
	private String orderNumber;	//订单号，唯一不重复
	private String phone;	//手机号
	private String productName;	//产品名称
	private String orderStatus;//订单状态
	private Double price ; //产品金额
	private String sspId;	//渠道来源标识
	private String ip;	//IP
	private Date addTime;	//下单时间
	private String businessType;//业务类型
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Date getAddTime() {
		return addTime;
	}
	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getSspId() {
		return sspId;
	}
	public void setSspId(String sspId) {
		this.sspId = sspId;
	}
	@Override
	public String toString() {
		return "QydgOrder [id=" + id + ", orderNumber=" + orderNumber + ", phone=" + phone + ", productName="
				+ productName + ", orderStatus=" + orderStatus + ", price=" + price + ", sspId=" + sspId + ", ip=" + ip
				+ ", addTime=" + addTime + ", businessType=" + businessType + "]";
	}
}
