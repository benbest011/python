package cn.richinfo.web.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import cn.richinfo.web.util.PropertiesUtils;
import cn.richinfo.util.StringUtil;

/**
 * 属性获取工具类
 */
public class PropertiesUtils {

	private static Properties properties;
	
	static{
		properties = new Properties();
		try {
			//eclipse 环境
//			properties.load(new FileInputStream(getWebRootPath()+"/conf.properties"));
			//maven 项目
			InputStream in =PropertiesUtils.class.getClassLoader().getResourceAsStream("web.conf.properties");  
			properties.load(in);  
		} catch (FileNotFoundException e) {
			System.out.println("Properties file not found!");
		} catch (IOException e) {
			System.out.println("Properties file IOException!"+e.getMessage());
		}
	}
	
	/**
	 * eclipse 环境
	 * @return
	 */
	@SuppressWarnings("unused")
	private static String getWebRootPath(){
		try {
			String path = PropertiesUtils.class.getResource("/").toURI().getPath();
			return new File(path).getParentFile().getParentFile().getCanonicalPath();
		} catch (Exception e) {
			
		}
		return null;
	}

	/**
	 * 获取属性值
	 * @param name
	 * @return
	 */
	public static String getProperties(String name){
		String value = null;
		
		if(StringUtil.isBlank(name)){
			return value;
		}
		//先查完整属性名，若有值就直接取值，为null再去查询开发或生产线值
		if(properties.containsKey(name)){
			value = properties.getProperty(name).trim();
		}else{
			String debug = getSingleProperties("DEBUG");
			if("true".equals(debug)){
				name = name+"@TEST" ;
			}else{
				name = name+"@PRO" ;
			}
			
			if(properties.containsKey(name)){
				value = properties.getProperty(name).trim();
			}
		}
		return value;
	}
	
	/**
	 * 获取单一的属性值
	 * @param name
	 * @return
	 */
	public static String getSingleProperties(String name){
		String value = null;
		
		if(StringUtil.isBlank(name)){
			return value;
		}
		if(properties.containsKey(name)){
			value = properties.getProperty(name).trim();
		}
		return value;
	}
	
	/**
	 * 获取属性值，可以设置默认值
	 * @param name
	 * @param defaultValue 默认返回值
	 * @return
	 */
	public static String getProperties(String name,String defaultValue){
		String value = null;
		if(StringUtil.isBlank(name)){
			return value;
		}
		if(properties.containsKey(name)&&!StringUtil.isBlank(properties.getProperty(name))){
			value = properties.getProperty(name).trim();
		}else{
			value = defaultValue;
		}
		return value;
	}
	
	
	//main
	public static void main(String[] args) {
		String test1 = PropertiesUtils.getProperties("DEBUG");
		
		System.out.println("测试值1="+test1);
	}
	
}
