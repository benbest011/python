package cn.richinfo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.richinfo.dao.QydgDao;
import cn.richinfo.domain.QydgOrder;
import cn.richinfo.service.MobilPhoneService;
import cn.richinfo.service.QydgService;
/**
 * 权益订购业务实现类
 * @author chuanye
 *
 */
@Service("qydgService")
public class QydgServiceImpl implements QydgService {
	
	@Autowired
	private QydgDao qydgDao;
	
	@Autowired
	MobilPhoneService mobilPhoneService;
	
	@Override
	public int saveQydgOrder(QydgOrder qydgOrder) {
		return qydgDao.saveQydgOrder(qydgOrder);
	}
	
	@Override
	public boolean count7day(String phone, String businessType) {
		QydgOrder qydgOrder = new QydgOrder();
		qydgOrder.setPhone(phone);
		qydgOrder.setBusinessType(businessType);
		return this.qydgDao.count7day(qydgOrder) > 0 ? true : false;
	}

}
