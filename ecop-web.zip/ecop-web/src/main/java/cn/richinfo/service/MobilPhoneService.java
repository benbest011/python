package cn.richinfo.service;
/**
 * 中国移动号码接口
 * @author chuanye
 *
 */
public interface MobilPhoneService {

	/**
	 * 是否中国移动号码
	 * @param phone
	 * @return
	 */
	boolean isMobilePhone(String phone);
	
	/**
	 * 判断号码是否某个省的用户，传递号码与省ID
	 * @param phone
	 * @param provinceId 省ID
	 * @return
	 */
	boolean checkPhoneArea(String phone, String provinceId);
	
	/**
	 * 产品订购
	 * @param servicenumber 手机号
	 * @param channelcode 渠道ID
	 * @param secret 密钥
	 * @param productid 产品编码
	 * @return
	 */
	String ECOP_SERVICE_0009(
			String servicenumber,
			String channelcode, 
			String secret,
			String productid
			);
}
