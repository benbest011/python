package cn.richinfo.service;

import javax.servlet.http.HttpServletRequest;

/**
 * 短信验证码接口
 * @author chuanye
 *
 */
public interface SmsService {
	
	/**
	 * 发送短信验证码
	 * @return
	 */
	String sendSMS(String phone);
	
	/**
	 * 验证短信验证码
	 * @return
	 */
	String checkSMS(String phone,String smsCode, HttpServletRequest request);
	
	/**
	 * 发送固定模板短信
	 * @param phone
	 * @return
	 */
	boolean sendSmsContent(String phone, String content);
	
}
