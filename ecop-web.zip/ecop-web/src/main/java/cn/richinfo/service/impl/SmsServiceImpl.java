package cn.richinfo.service.impl;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import cn.richinfo.service.SmsService;
import cn.richinfo.util.DateUtil;
import cn.richinfo.util.HttpClientUtil;
import cn.richinfo.util.MessageDigestUtil;

/**
 * 短信验证码实现
 * @author chuanye
 *
 */
@Service("smsService")
public class SmsServiceImpl implements SmsService {
	private static Logger log = Logger.getLogger(SmsServiceImpl.class);
	
	/**
	 * 下发短信验证码请求
     * @param mobile 手机号
     * @param request 
     * @return json
	 */
	@Override
	public String sendSMS(String phone) {
		return null;
	}

    /**
     * 短信验证码校验请求
     * @param mobile 手机号
     * @param smsCode 用户输入的验证码
     * @param request
     * @return json
     * 
    */
	@Override
	public String checkSMS(String phone, String smsCode, HttpServletRequest request) {
		return null;
	}

	@Override
	public boolean sendSmsContent(String phone, String content) {
		//接口
	    String url = "http://160.19.212.218:8080/eums/utf8/send_strong.do?";
		String name = "cxkjyzm";
		String password = "oau8hmkf";
		String seed = DateUtil.getToday("yyyyMMddHHmmss");
		
		password = MessageDigestUtil.getMD5(password).toLowerCase();
		String key = MessageDigestUtil.getMD5(password + seed).toLowerCase();
		
		String dest = phone;//手机号
		
		//为空或可不填写参数
//		String ext = "";
//		String reference = "";
//		String delay = "";
		@SuppressWarnings("deprecation")
		String reqUrl = new StringBuffer()
				.append(url)
				.append("name="+ java.net.URLEncoder.encode(name))
				.append("&seed="+ java.net.URLEncoder.encode(seed))
				.append("&key="+ java.net.URLEncoder.encode(key))
				.append("&dest="+ java.net.URLEncoder.encode(dest))
				.append("&content="+ java.net.URLEncoder.encode(content)).toString();
        
        log.debug("["+phone+"]参数报文:"+ reqUrl);
        
		String resp = null ;
		String resultCode = null;
		try {
			resp = HttpClientUtil.httpPostRequest(reqUrl); 
			//成功返回：success:0603015522454756885
			resultCode = resp.split(":")[0];
		} catch (Exception e) {
			log.error("["+phone+"]验证码返回报文异常");
			e.printStackTrace();
		}
		log.info("["+phone+"]验证码下发请求报文:"+ reqUrl);
		log.info("["+phone+"]验证码下发返回报文:"+ resp);
		
		return "success".equals(resultCode) ? true : false;
	}

}
