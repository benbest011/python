package cn.richinfo.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

import cn.richinfo.service.MobilPhoneService;
import cn.richinfo.util.DateUtil;
import cn.richinfo.util.HttpClientUtil;
import cn.richinfo.util.JsonUtil;
import cn.richinfo.util.MessageDigestUtil;
import cn.richinfo.util.Xml2JsonUtil;
import cn.richinfo.web.util.PropertiesUtils;

@Service("mobilPhoneService")
public class MobilPhoneServiceImpl implements MobilPhoneService {

	private static Logger log = Logger.getLogger(MobilPhoneServiceImpl.class);
	
	//是否中国移动用户
	private static final String IS_MOBILE_PHONE = PropertiesUtils.getProperties("IS_MOBILE_PHONE");
	
	//判断中国移动用户与省ID是否匹配
	private static final String CHECK_PHONE_AREA = PropertiesUtils.getProperties("CHECK_PHONE_AREA");
	
	//权益订购地址
	private static final String ECOP_API = PropertiesUtils.getProperties("ECOP_API");
	
	
	@Override
	public boolean isMobilePhone(String phone) {
		String resp = null;
		try {
			resp = HttpClientUtil.httpGetRequest(IS_MOBILE_PHONE.replace("{phone}", phone));
		} catch (Exception e) {
			log.error("["+phone+"]判断是否移动号码异常:" + resp);
			e.printStackTrace();
		}
		if(resp != null && resp.equals("true")) {
			return true;
		}else {
			return false ;
		}
	}

	@Override
	public boolean checkPhoneArea(String phone, String provinceId) {
		String resp = null;
		try {
			String url = CHECK_PHONE_AREA.replace("{phone}", phone)
					.replace("{provinceId}", provinceId);
			resp = HttpClientUtil.httpGetRequest(url);
		} catch (Exception e) {
			log.error("["+phone+"]判断是否号码省份一致性异常:" + resp);
			e.printStackTrace();
		}
		if(resp != null && resp.equals("true")) {
			return true;
		}else {
			return false ;
		}
	}

	@Override
	public String ECOP_SERVICE_0009(
			String servicenumber,
			String channelcode, 
			String secret,
			String productid
			) {
		String timestamp = DateUtil.getTimeStamp(10); //10位时间戳
		String channelorderno = DateUtil.getUIIDByCurrentTime();//订单号
		secret = MessageDigestUtil.getMD5(secret + timestamp + channelcode + channelorderno + servicenumber + productid).toUpperCase();
		
		StringBuffer reqXml = new StringBuffer()
				.append("<request>")
				.append("<channelcode>"+ channelcode +"</channelcode>")
				.append("<secret>"+ secret +"</secret>")
				.append("<timestamp>"+ timestamp +"</timestamp>")
				.append("<channelorderno>"+ channelorderno +"</channelorderno>")
				.append("<servicenumber>"+ servicenumber +"</servicenumber>")
				.append("<productid>"+ productid +"</productid>")
				.append("</request>");
		
		String respXml = null;
		String json = null ;
		String resultCode = null;
		try {
			respXml = HttpClientUtil.httpPostXmlRequest(ECOP_API, reqXml.toString());
			json = Xml2JsonUtil.xml2JSON(respXml);
			//解析json
	        JSONObject jsonObject = JsonUtil.getJSONObject(json);
	        resultCode = jsonObject.getString("code"); //0时表示成功
	       
	        //失败时
	        if(!"0".equals(resultCode)) {
		        JSONObject retinfoObject = jsonObject.getJSONObject("body")
		        		.getJSONObject("productorderresp")
		        		.getJSONObject("msgheader")
		        		.getJSONObject("retinfo");
		        
		        resultCode = retinfoObject.getString("retmsg"); //失败原因
	        }
		} catch (Exception e) {
			log.error("["+servicenumber+"]订购产品异常");
			e.printStackTrace();
		}
		log.info("["+servicenumber+"]订购产品请求API:"+ ECOP_API);
		log.info("["+servicenumber+"]订购产品请求报文:"+ reqXml);
		log.info("["+servicenumber+"]订购产品返回json:"+ json);
		log.info("["+servicenumber+"]订购产品返回报文:"+ respXml);
		
		return resultCode;
	}
	
	/*
	public static void main(String[] args) {
		String respXml = "<response>\n" + 
				"	<code>0</code>\n" + 
				"	<msg>成功</msg>\n" + 
				"<channelorderno>2018010113800000000</channelorderno>\n" + 
				"<orderno>201801010101010</orderno>\n" + 
				"	<body>\n" + 
				"		<productorderresp>\n" + 
				"			<msgheader>\n" + 
				"				<req_seq>20121001123030000001</req_seq>\n" + 
				"				<ope_seq>20160507142901595001</ope_seq>\n" + 
				"				<retinfo>\n" + 
				"					<rettype>0</rettype>\n" + 
				"					<retcode>0</retcode>\n" + 
				"					<retmsg>成功</retmsg>\n" + 
				"				</retinfo>\n" + 
				"			</msgheader>\n" + 
				"			<msgbody>\n" + 
				"				<orderinfo>\n" + 
				"				<orderseq>省公司接口返回的订单号</orderseq>\n" + 
				"				</orderinfo>\n" + 
				"			</msgbody>\n" + 
				"		</productorderresp>\n" + 
				"	</body>	\n" + 
				"</response>";
		
		String json = Xml2JsonUtil.xml2JSON(respXml);
		
		//解析json
        JSONObject jsonObject = JsonUtil.getJSONObject(json);
        String resultCode = jsonObject.getString("code");
        
        JSONObject retinfoObject = jsonObject.getJSONObject("body")
        		.getJSONObject("productorderresp")
        		.getJSONObject("msgheader")
        		.getJSONObject("retinfo");
        
        String retmsg = retinfoObject.getString("retmsg");
        
        System.out.println(retmsg);
        
	}
	*/
	
}
