package cn.richinfo.service;

import cn.richinfo.domain.QydgOrder;
/**
 * 权益订购业务接口
 * @author chuanye
 *
 */
public interface QydgService {
	/**
	 * 保存订单信息
	 * @return
	 */
	int saveQydgOrder(QydgOrder qydgOrder);
	
	/**
	 * 查询最近7天是否下过订单
	 * @param phone
	 * @param businessType 商户类型
	 * @return
	 */
	boolean count7day(String phone, String businessType);
	
	/**
	 * CCTV产品订购
	 * @param phone 手机号
	 * @param channelcode 渠道ID
	 * @param secret 密钥
	 * @param productid 产品编码
	 * @return
	 */
//	boolean cctvQyOpen(String phone,
//			String channelcode,
//			String productid);
}
