//手机号码验证
function checkPhone(str){
	var reg=/^0{0,1}(13[0-9]|14[0-9]|15[0-9]|18[0-9]|17[0-9])[0-9]{8}$/;
	if (reg.test(str)){
		return true;
	} else {
		return false;
	}
}

//纯数字验证
function checkNum(str){
	var reg=/^[0-9]{1,20}$/;
	if (reg.test(str)){
		return true;
	} else {
		return false;
	}
}

//验证码验证
function checkCode(str){
	var reg=/^[0-9]{6}$/;
	if (reg.test(str)){
		return true;
	} else {
		return false;
	}
}


//验证码倒计时60秒
var lock;
var nums=60;
function sendCode(){
	$("#sendCode").attr("disabled","disabled");
	$("#sendCode").html("重新获取(<span>60</span>)");
	lock=window.setInterval(doLoop,1000);
}

function doLoop(){
	 nums--;
	 if(nums > 0){
		 $("#sendCode").html("重新获取(<span>"+nums+"</span>)");
	 }else{
		 $("#sendCode").html("获取验证码");
		 $("#sendCode").removeAttr("disabled"); 
		 window.clearInterval(lock);
		 nums = 60;
	 }
}
//停止
function stopDoLoop(){
	 $("#sendCode").text("获取验证码");
	 $("#sendCode").removeAttr("disabled"); 
	 window.clearInterval(lock);
	 nums = 60;
}
//验证码倒计时 end

//判断是否微信浏览器
function isWeixn(){ 
	var ua = navigator.userAgent.toLowerCase(); 
	if(ua.match(/MicroMessenger/i)=="micromessenger") { 
		return true; 
	} else { 
		return false; 
	} 
}

//判断是否和飞信APP
function isHefeixin(){
	var ua = navigator.userAgent.toLowerCase(); 
	if(ua.match(/hefeixin/i)=="hefeixin") { 
		return true; 
	} else { 
		return false; 
	}
}


//是否移动端访问
function isMobile(){
	return /Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent) ? true : false ;
}


//判断访问终端
var browser={
  versions:function(){
    var u = navigator.userAgent, 
      app = navigator.appVersion;
    return {
      trident: u.indexOf('Trident') > -1, //IE内核
      presto: u.indexOf('Presto') > -1, //opera内核
      webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
      gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
      mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
      ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
      android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
      iPhone: u.indexOf('iPhone') > -1 , //是否为iPhone或者QQHD浏览器
      iPad: u.indexOf('iPad') > -1, //是否iPad
      webApp: u.indexOf('Safari') == -1, //是否web应用程序，没有头部与底部
      weixin: u.indexOf('MicroMessenger') > -1, //是否微信
      hefeixin: u.indexOf('hefeixin') > -1, //是否和飞信
      qq: u.match(/\sQQ/i) == " qq" //是否QQ
    };
  }(),
  language:(navigator.browserLanguage || navigator.language).toLowerCase()
}
