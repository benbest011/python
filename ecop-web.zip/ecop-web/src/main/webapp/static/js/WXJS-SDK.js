/**
 * 微信动态分享
 */
//点击  提交按钮
$("#sub-btn").click(function(event) {
	var phone = $(".sub-phone").val();
	var mphone = $(".sub-mphone").val();
	
	var snPhone = $("#snPhone").val();
	var aesPhone = $("#aesPhone").val();
	
	if(snPhone.length == 11 && aesPhone != ""){
		phone = mphone;
	}
	
	$(this).attr("disabled","true");
	setTimeout("$('#sub-btn').removeAttr('disabled')",3000);
	if(phone.length!=11 || !checkPhone(phone)){
		win02("请输入正确的手机号码！<br>只限中国移动用户!");//错误状态
		return false;
	}
  
   layer.open({
	   shadeClose:false
	   ,style: 'font-size: 27px;'
	   ,content: '您确定用此号码('+phone+')参与活动?'
	    ,btn: ['确定参与', '重新输入']
	    ,yes: function(index){
	      layer.close(index);
	      layer.open({type: 2,shadeClose:false,content: '分享链接生成中...',time:3});
	      ajaxSubmint(phone);
	      //layer.closeAll();
	    }
	  });

});

function ajaxSubmint(phone){
	//动态微信分享信息
	var submitID = $("#submitID").val();
  	$.ajax({
		cache : false, 
		async : false,
		timeout : 10000,
		data : {"phone" : phone, "submitID": submitID},
		type : "POST",
		url : basePath + "saleurl.do",
		dataType : "json",
		contentType: "application/x-www-form-urlencoded; charset=utf-8", 
		success : function(data) {
			switch (data.status) {
			case 2:
				$("#win01").show();
				break;
			case 3:
				win02("很抱歉！<br>本活动只限广东省移动用户!");
				break;
			case 9:
				win02("很抱歉！<br>本活动只限广东省移动用户<br>请稍候再试!");
				//win02("很抱歉！<br>无法获取号码归属地<br>请稍候再试!");
				break;
			case 12:
				win02("很抱歉！<br>您非受邀请用户参本活动!");
				break;
			case 13:
				win02("很抱歉！<br>本活动只限开通和飞信企业成员!");
				break;
			case 14:
				win02("很抱歉！<br>本活动只限开通和飞信企业成员!");
				break;
			case 22:
				win02("很抱歉！<br>本活动只限陕西省移动用户!");
				break;
			case 200:
				if(isWeixn()){
	      			$("#text01").text("呼朋唤友").addClass("text01");
	      			var str = '<div class="text02">你的流量已在路上，马上告诉好友！</div>';
	      			str += '<a class="btn-red">立即分享</a>';
	      			$(".invite").html(str);
	      			wxConfigInit(data.saleUrl);
				}else{
	      			$("#text01").text("呼朋唤友").addClass("text01");
	      			var str = '<div class="text02">你的流量已在路上，马上告诉好友！</div>';
	      			str += '<div class="text02">打开你的助力活动页，然后分享出去！</div>';
	      			str += '<div class="text02 salseurl">'+data.saleUrl+'.html</div>';
	      			str += '<a class="btn-red" href="'+data.saleUrl+'.html">打开助力活动页</a>';
	      			$(".invite").html(str);
				}

				break;
			default:
				layer.open({content: '分享链接生成失败,请重试!', skin: 'msg', time: 3});
				window.location.href = basePath ;
				break;
			}
  		},
  		error : function(xhr,textStatus) {
  			layer.open({content: '分享链接生成失败,请稍候重试!', skin: 'msg', time: 3});
  		}
  	});
}

//加载分享初始信息
function wxConfigInit(saleUrl){
	var url = location.href.split('#')[0];//url不能写死
	var shareTitle = '我在参加和飞信“推荐有礼”活动,免费拿流量';//标题
	var shareDesc = '快来帮我助力,你也可以免费获得300分钟多方通话时长'; //描述
	var shareImgUrl = wapRoot+'images/tjyl.png';//图片
	var shareLink = saleUrl=='' ? basePath : basePath+saleUrl+'.html';	//链接
	
	//url = encodeURIComponent(url);	//好大的坑，官方说要转码，实质不用转码
	
	//动态微信分享信息
	$.ajax({
        cache : false, 
        async : false,
        data : {"url" : url},
		type : "POST",
		url : basePath + "wxconfinit.do",
		dataType : "json",
		contentType: "application/x-www-form-urlencoded; charset=utf-8", 
		success : function(wxConfig) {
			wx.config({
			    debug: false, // 开启调试模式
			    
			    appId: wxConfig.appId, //公众号的唯一标识
			    timestamp: wxConfig.timestamp, //生成签名的时间戳
			    nonceStr: wxConfig.nonceStr, //生成签名的随机串
			    signature: wxConfig.signature,//签名，见附录1
				jsApiList: [  //网页服务接口
				    'onMenuShareTimeline', //分享到朋友圈
				    'onMenuShareAppMessage', //发送给朋友
				    'onMenuShareQQ',  //分享到QQ
				    'onMenuShareWeibo', //分享到微博
				    'onMenuShareQZone' //分享到QQ空间
				]
			});

		},
		error : function(xhr,textStatus) {
			//layer.open({content: '当前访问人数过多,请稍候再试!', skin: 'msg', time: 2});
		}
		
	});
	
	wx.ready(function(){
	    // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，
		//config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，
		//则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
		
		//获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
		wx.onMenuShareTimeline({
		    title: shareTitle, // 分享标题
		    link: shareLink, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
		    imgUrl: shareImgUrl, // 分享图标
		    success: function () { 
		    	//alert('分享成功');
		    },
		    cancel: function () { 
		        // 用户取消分享后执行的回调函数
		    }
		});
		
		//获取“分享给朋友”按钮点击状态及自定义分享内容接口
		wx.onMenuShareAppMessage({
		    title: shareTitle, // 分享标题
		    desc: shareDesc, // 分享描述
		    link: shareLink, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
		    imgUrl: shareImgUrl, // 分享图标
		    type: '', // 分享类型,music、video或link，不填默认为link
		    dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
		    success: function () { 
		    	//alert('分享成功');
		    },
		    cancel: function () { 
		        // 用户取消分享后执行的回调函数
		    }
		});
		
		//获取“分享到QQ”按钮点击状态及自定义分享内容接口
		wx.onMenuShareQQ({
		    title: shareTitle, // 分享标题
		    desc: shareDesc, // 分享描述
		    link: shareLink, // 分享链接
		    imgUrl: shareImgUrl, // 分享图标
		    success: function () { 
		    	//alert('分享成功');
		    },
		    cancel: function () { 
		       // 用户取消分享后执行的回调函数
		    }
		});
		
		//获取“分享到腾讯微博”按钮点击状态及自定义分享内容接口
		wx.onMenuShareWeibo({
		    title: shareTitle, // 分享标题
		    desc: shareDesc, // 分享描述
		    link: shareLink, // 分享链接
		    imgUrl: shareImgUrl, // 分享图标
		    success: function () { 
		    	//alert('分享成功');
		    },
		    cancel: function () { 
		        // 用户取消分享后执行的回调函数
		    }
		});
		
		//获取“分享到QQ空间”按钮点击状态及自定义分享内容接口
		wx.onMenuShareQZone({
		    title: shareTitle, // 分享标题
		    desc: shareDesc, // 分享描述
		    link: shareLink, // 分享链接
		    imgUrl: shareImgUrl, // 分享图标
		    success: function () { 
		    	//alert('分享成功');
		    },
		    cancel: function () { 
		        // 用户取消分享后执行的回调函数
		    }
		});
		
	});
	
	wx.error(function(res){
	    // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
		//alert(res.errMsg);
	});
	
}

