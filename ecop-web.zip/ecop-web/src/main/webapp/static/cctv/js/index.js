// JavaScript Document
var isdg = 0;

$(function(){
    scales('.hfx',750,100);
	$(window).resize(function(){
		scales('.hfx',750,100);
	})
	
	$(".dgsm").bind("click",function(){
		$(".zhazao").show();
		$("#sm_tk").show();
	    //调用
        var divScroll = new DivScroll('#cont_n');
	})
	
	$(".close").bind("click",function(){
		$(".zhazao").hide();
		$("#sm_tk").hide();
		$("#win1").hide();
		$("#yz_tk").hide();
	})
	
	$(".tu_bar_i").bind("click",function(){
		if(isdg == 1){
			 msg('有效期内不可重复订购');
			 return false;
		}
		$("#proid").val($(this).attr("proid"));
		$(".zhazao").show();
		$("#yz_tk").show();
	})
	
	//验证码倒计时
	$(".get_code").bind("click",function(){
		 if($(this).hasClass("done")){
			 return false;
		 }else {
			 var phone = $(".the_phone").val();
			 if(!checkPhone(phone)){
				 msg('请输入正确的广东移动手机号');
				 return false;
			 }
			 $(this).addClass("done");
			 $(this).html("重新获取(<span>60</span>)");
			 timerr = setTimeout(autocont,1000);
			 requestSmsCode(phone);
		 }
	 })
	 
	 function autocont() {
		 if($(".get_code span").text()==0){
			 $(".get_code").removeClass("done").html("获取验证码");
		 }else {
			 $(".get_code span").text(parseInt($(".get_code span").text()) - 1);
			 timerr = setTimeout(autocont,1000);
		 }
	}
	//验证码倒计时 end
	
	//订购
	$(".ljdg").bind("click",function(){
		var phone = $(".the_phone").val();
		var yzm = $(".the_yzm").val();
		var aesPhone = $("#aesPhone").val();
		
		 if(aesPhone == "" && !checkPhone(phone)){
		     $(".the_error").html("请输入正确的广东移动手机号").show();
			 setTimeout(function(){$(".the_error").fadeOut(2000);},1000);
			 return false;
		 }
		 
		 if(aesPhone == "" && !checkCode(yzm)){
		     $(".the_error").html("请输入正确的验证码").show();
			 setTimeout(function(){$(".the_error").fadeOut(2000);},1000);
			 return false;
		 }
		 
		$(this).attr("disabled",true);
		setTimeout("$('.ljdg').removeAttr('disabled')",10000);
		
		layer.open({type: 2,shadeClose:false,content: '正在订购中,请稍候...', time:3});
		$.ajax({
		    cache : false, 
		    async : true,
		    data : {
		    	"phone" : phone,
		    	"yzm" : yzm,
		    	"aesPhone" : aesPhone,
		    	"sspId" : $("#sspId").val(),
		    	"proid" : $("#proid").val()
		    	},
			type : "POST",
			url : ROOT+"cctv/save",
			dataType : "json",
			contentType: "application/x-www-form-urlencoded; charset=utf-8", 
			success : function(data) {
				console.info(data);
				layer.closeAll('loading');
				if(data.stauts == 200){//下单成功
					if(data.msg == "0"){
						isdg = 1;
						$("#yz_tk .tk_tankuang_t").html("温馨提示");
						$("#yz_tk .tk_tankuang_b").html("<p>您的订购申请已成功提交<br>订购成功后会以短信通知<br>请留意！</p>");
					}else{
						$("#yz_tk .tk_tankuang_t").html("温馨提示");
						$("#yz_tk .tk_tankuang_b").html('<p>非常抱歉<br>产品订购失败!<br>原因:'+ data.msg +'</p>');
					}

				}else{
					layer.closeAll('loading');
					msg(data.msg);
				}
			},
			error : function(data) {
				layer.closeAll('loading');
				msg('系统繁忙,订购失败!');
			}
		});
	 })
   
	var DivScroll = function( cont_n ){
        //如果没有这个元素的话，那么将不再执行下去
        if ( !document.querySelector( cont_n ) ) return ;

        this.popupLayer = document.querySelector( cont_n ) ;
        this.startX = 0 ;
        this.startY = 0 ;

        this.popupLayer.addEventListener('touchstart', function (e) {
            this.startX = e.changedTouches[0].pageX;
            this.startY = e.changedTouches[0].pageY;
        }, false);

        // 仿innerScroll方法
        this.popupLayer.addEventListener('touchmove', function (e) {

            e.stopPropagation();

            var deltaX = e.changedTouches[0].pageX - this.startX;
            var deltaY = e.changedTouches[0].pageY - this.startY;

            // 只能纵向滚
            if(Math.abs(deltaY) < Math.abs(deltaX)){
                e.preventDefault();
                return false;
            }

            if( this.offsetHeight + this.scrollTop >= this.scrollHeight){
                if(deltaY < 0) {
                    e.preventDefault();
                    return false;
                }
            }
            if(this.scrollTop === 0){
                if(deltaY > 0) {
                    e.preventDefault();
                    return false;
                }
            }
            // 会阻止原生滚动
            // return false;
        },false);

    }

});
    

/**
 * 发送短信校验码
 * @param obj
 */
function requestSmsCode(phone) {
	$.ajax({
		cache : false, 
		async : true,
		url :  ROOT + "cctv/sendSms", 
		type : 'post' ,
		data : {"phone" : phone},
		dataType : "json",
		contentType: "application/x-www-form-urlencoded; charset=utf-8", 
		success : function(data){
			console.info(data);
			if(data.stauts == 200){
				msg('发送成功');
			}else{
				msg(data.msg);
				$(".get_code").removeClass("done").html("获取验证码");
			}
		},
		error:function(){
			msg('发送失败!');
		}
	});
}

/**
 * 自动登录
 */
function autoLogin(snPhone, aesPhone){
	
	$("#yz_tk .tk_tankuang_t").html("温馨提示");
	$("#yz_tk .tk_tankuang_b .tk_tankuang_b_i .the_phone").hide();
	$("#yz_tk .tk_tankuang_b .yzmbox").html("<p>您【"+ snPhone +"】将提交订购申请<br>订购成功后会以短信通知</p>");
	//$("#yz_tk .tk_tankuang_b .tk_tankuang_b_i").html("");
	//$(".the_phone").val(snPhone);
	//$(".the_phone").attr("disabled",true);
	
	//$(".yzmbox").hide();
	$("#snPhone").val(snPhone);
	$("#aesPhone").val(aesPhone);
}

//退出登录
function loginOut(ROOT,arg){
	$(".the_phone").attr("disabled",false);
	$(".yzmbox").show();
	$(".loginOut").hide();
	
	$("#snPhone").val("");
	$("#aesPhone").val("");
}

function msg(str){
    $(".the_error").html(str).show();
	setTimeout(function(){$(".the_error").fadeOut(2000);},2000);
}
