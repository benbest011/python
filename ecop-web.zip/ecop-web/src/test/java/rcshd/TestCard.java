package rcshd;

import java.util.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.richinfo.domain.QydgOrder;
import cn.richinfo.service.QydgService;
import cn.richinfo.service.SmsService;
import cn.richinfo.util.RandomUtil;
import cn.richinfo.util.RequestUtil;


public class TestCard {
	
	ApplicationContext ctx = 
			new ClassPathXmlApplicationContext("applicationContext.xml");
	SmsService smsService = (SmsService) ctx.getBean("smsService");
	QydgService qydgService = (QydgService) ctx.getBean("qydgService");

	@Test
	public void test2() {
		
		
		
		System.out.println(this.qydgService.count7day("15814850826", "cctv"));
		
//		QydgOrder qydgOrder = new QydgOrder();
//		qydgOrder.setOrderNumber(RandomUtil.getNumBylen(20)); //订单号
//		qydgOrder.setPhone("phone");
//		qydgOrder.setProductName("subject");
//		qydgOrder.setOrderStatus("orderStatus");
//		qydgOrder.setPrice(0.00);
//		qydgOrder.setSspId("sspId");
//		qydgOrder.setIp("RequestUtil.getUserIp");
//		qydgOrder.setAddTime(new Date());
//		qydgOrder.setBusinessType("cctv");
//		
//		System.out.println(this.qydgService.saveQydgOrder(qydgOrder));
		
		//System.out.println(this.qydgService.getQydgOrderByPhone("1581485082611"));
		
	}
	
	
}
